package co.getair.meerkat.video.broadcast.coremedia.iso.boxes;

public abstract interface FullBox extends Box
{
  public abstract int getFlags();

  public abstract int getVersion();

  public abstract void setFlags(int paramInt);

  public abstract void setVersion(int paramInt);
}