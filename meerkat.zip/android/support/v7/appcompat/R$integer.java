package android.support.v7.appcompat;

public final class R$integer
{
  public static final int abc_config_activityDefaultDur = 2131689472;
  public static final int abc_config_activityShortDur = 2131689473;
  public static final int abc_max_action_buttons = 2131689474;
}