package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.view.View;

class ViewCompatBase
{
  static ColorStateList getBackgroundTintList(View paramView)
  {
    if ((paramView instanceof TintableBackgroundView))
      return ((TintableBackgroundView)paramView).getSupportBackgroundTintList();
    return null;
  }

  static PorterDuff.Mode getBackgroundTintMode(View paramView)
  {
    if ((paramView instanceof TintableBackgroundView))
      return ((TintableBackgroundView)paramView).getSupportBackgroundTintMode();
    return null;
  }

  static boolean isLaidOut(View paramView)
  {
    return (paramView.getWidth() > 0) && (paramView.getHeight() > 0);
  }

  static void setBackgroundTintList(View paramView, ColorStateList paramColorStateList)
  {
    if ((paramView instanceof TintableBackgroundView))
      ((TintableBackgroundView)paramView).setSupportBackgroundTintList(paramColorStateList);
  }

  static void setBackgroundTintMode(View paramView, PorterDuff.Mode paramMode)
  {
    if ((paramView instanceof TintableBackgroundView))
      ((TintableBackgroundView)paramView).setSupportBackgroundTintMode(paramMode);
  }
}