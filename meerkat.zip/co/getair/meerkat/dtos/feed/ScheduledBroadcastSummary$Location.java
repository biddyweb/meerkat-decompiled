package co.getair.meerkat.dtos.feed;

class ScheduledBroadcastSummary$Location
{
  private String city;
  private String country;

  ScheduledBroadcastSummary$Location(ScheduledBroadcastSummary paramScheduledBroadcastSummary)
  {
  }
}