package co.getair.meerkat;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "co.getair.meerkat";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final String MEERKAT_API_KEY = "97699257d0dd880683e5f3ddfe543e36d2b9da6001ada81ea89860c5a8a5c12e";
  public static final int VERSION_CODE = 30;
  public static final String VERSION_NAME = "1.0";
}