package co.getair.meerkat;

public final class R$plurals
{
  public static final int tw__time_hours = 2131755008;
  public static final int tw__time_mins = 2131755009;
  public static final int tw__time_secs = 2131755010;
}