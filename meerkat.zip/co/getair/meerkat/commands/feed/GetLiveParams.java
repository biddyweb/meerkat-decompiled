package co.getair.meerkat.commands.feed;

public class GetLiveParams
{
  boolean shouldFilter = true;

  public GetLiveParams(boolean paramBoolean)
  {
    this.shouldFilter = paramBoolean;
  }
}