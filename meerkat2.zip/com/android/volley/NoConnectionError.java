package com.android.volley;

public class NoConnectionError extends NetworkError
{
  public NoConnectionError()
  {
  }

  public NoConnectionError(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}