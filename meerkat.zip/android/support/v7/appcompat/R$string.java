package android.support.v7.appcompat;

public final class R$string
{
  public static final int abc_action_bar_home_description = 2131296257;
  public static final int abc_action_bar_home_description_format = 2131296258;
  public static final int abc_action_bar_home_subtitle_description_format = 2131296259;
  public static final int abc_action_bar_up_description = 2131296260;
  public static final int abc_action_menu_overflow_description = 2131296261;
  public static final int abc_action_mode_done = 2131296262;
  public static final int abc_activity_chooser_view_see_all = 2131296263;
  public static final int abc_activitychooserview_choose_application = 2131296264;
  public static final int abc_search_hint = 2131296265;
  public static final int abc_searchview_description_clear = 2131296266;
  public static final int abc_searchview_description_query = 2131296267;
  public static final int abc_searchview_description_search = 2131296268;
  public static final int abc_searchview_description_submit = 2131296269;
  public static final int abc_searchview_description_voice = 2131296270;
  public static final int abc_shareactionprovider_share_with = 2131296271;
  public static final int abc_shareactionprovider_share_with_application = 2131296272;
  public static final int abc_toolbar_collapse_description = 2131296273;
}