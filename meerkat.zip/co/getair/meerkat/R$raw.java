package co.getair.meerkat;

public final class R$raw
{
  public static final int gtm_analytics = 2131230720;
  public static final int rawres = 2131230721;
  public static final int tw__cacerts = 2131230722;
}