package co.getair.meerkat;

public final class R$animator
{
  public static final int comment_view_animator = 2131099648;
}