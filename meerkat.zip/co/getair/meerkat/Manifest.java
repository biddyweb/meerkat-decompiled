package co.getair.meerkat;

public final class Manifest
{
  public static final class permission
  {
    public static final String C2D_MESSAGE = "co.getair.meerkat.permission.C2D_MESSAGE";
  }
}