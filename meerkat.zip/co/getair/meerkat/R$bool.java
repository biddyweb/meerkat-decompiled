package co.getair.meerkat;

public final class R$bool
{
  public static final int abc_action_bar_embed_tabs = 2131427328;
  public static final int abc_action_bar_embed_tabs_pre_jb = 2131427329;
  public static final int abc_action_bar_expanded_action_views_exclusive = 2131427330;
  public static final int abc_config_actionMenuItemAllCaps = 2131427331;
  public static final int abc_config_allowActionMenuItemTextWithIcon = 2131427332;
  public static final int abc_config_closeDialogWhenTouchOutside = 2131427333;
  public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131427334;
  public static final int isTablet = 2131427335;
}