package co.getair.meerkat;

public final class R$array
{
  public static final int report_options = 2131361792;
}