package co.getair.meerkat;

public class TrackedEventsNames
{
  public static final String INCREMENT_WATCH_COUNT = "watch count";
  public static final String WATCH_EVENT = "watch";
}