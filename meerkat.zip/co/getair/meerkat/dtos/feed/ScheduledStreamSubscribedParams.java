package co.getair.meerkat.dtos.feed;

public class ScheduledStreamSubscribedParams
{
  String tweetId;

  public ScheduledStreamSubscribedParams(String paramString)
  {
    this.tweetId = paramString;
  }
}