package co.getair.meerkat.video.broadcast.googlecode.mp4parser.boxes.mp4.objectdescriptors;

@Descriptor(tags={0})
public abstract class ObjectDescriptorBase extends BaseDescriptor
{
}