package co.getair.meerkat.video.broadcast.dfh.thread;

public class ThreadPuddleException extends RuntimeException
{
  private static final long serialVersionUID = 1L;

  public ThreadPuddleException(String paramString)
  {
    super(paramString);
  }
}