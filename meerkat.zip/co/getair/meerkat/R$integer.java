package co.getair.meerkat;

public final class R$integer
{
  public static final int abc_config_activityDefaultDur = 2131689472;
  public static final int abc_config_activityShortDur = 2131689473;
  public static final int abc_max_action_buttons = 2131689474;
  public static final int google_play_services_version = 2131689475;
}