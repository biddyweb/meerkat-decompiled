package android.support.v4.os;

import android.os.Trace;

class TraceJellybeanMR2
{
  public static void beginSection(String paramString)
  {
    Trace.beginSection(paramString);
  }

  public static void endSection()
  {
    Trace.endSection();
  }
}