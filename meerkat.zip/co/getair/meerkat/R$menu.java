package co.getair.meerkat;

public final class R$menu
{
  public static final int instabug_support_activity_menu = 2131886080;
  public static final int menu_comments = 2131886081;
  public static final int menu_feed = 2131886082;
  public static final int menu_home = 2131886083;
  public static final int menu_landing = 2131886084;
  public static final int menu_login_sequence = 2131886085;
  public static final int menu_profile = 2131886086;
  public static final int menu_schedule_broadcast = 2131886087;
  public static final int menu_user_list = 2131886088;
  public static final int menu_user_list_item = 2131886089;
  public static final int menu_watch = 2131886090;
}