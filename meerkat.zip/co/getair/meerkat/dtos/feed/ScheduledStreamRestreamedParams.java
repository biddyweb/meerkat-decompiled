package co.getair.meerkat.dtos.feed;

public class ScheduledStreamRestreamedParams
{
  String tweetId;

  public ScheduledStreamRestreamedParams(String paramString)
  {
    this.tweetId = paramString;
  }
}