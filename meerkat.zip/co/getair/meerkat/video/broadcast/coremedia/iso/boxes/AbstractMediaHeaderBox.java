package co.getair.meerkat.video.broadcast.coremedia.iso.boxes;

import co.getair.meerkat.video.broadcast.googlecode.mp4parser.AbstractFullBox;

public abstract class AbstractMediaHeaderBox extends AbstractFullBox
{
  protected AbstractMediaHeaderBox(String paramString)
  {
    super(paramString);
  }
}