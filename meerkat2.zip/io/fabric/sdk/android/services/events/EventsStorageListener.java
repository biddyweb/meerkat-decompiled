package io.fabric.sdk.android.services.events;

public abstract interface EventsStorageListener
{
  public abstract void onRollOver(String paramString);
}