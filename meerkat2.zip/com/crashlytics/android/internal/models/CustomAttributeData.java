package com.crashlytics.android.internal.models;

public class CustomAttributeData
{
  public final String key;
  public final String value;

  public CustomAttributeData(String paramString1, String paramString2)
  {
    this.key = paramString1;
    this.value = paramString2;
  }
}