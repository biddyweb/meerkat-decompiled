package co.getair.meerkat.commands.webview;

import org.puremvc.java.multicore.patterns.command.SimpleCommand;

public class WebViewOpenUrlCommand extends SimpleCommand
{
}